/*
 * MotorPID_Position.cpp - Multi-motor version
 * Tác giả: Nguyễn Khắc Tùng Lâm
 * Facebook: Lâm Tùng | TikTok: @Tunglam0605 | SĐT: 0325270213
 * Đóng gói và nâng cấp bởi ChatGPT OpenAI - 2025
 *
 * Thư viện điều khiển vị trí động cơ DC dùng encoder & PID đa động cơ.
 */

#include "MotorPID_Position.h"

// Static variables
MotorPID_Position* MotorPID_Position::motorList[MAX_PID_MOTORS] = {nullptr};
uint8_t MotorPID_Position::motorCount = 0;

// Constructor
MotorPID_Position::MotorPID_Position(uint8_t enca, uint8_t encb, uint8_t pwmF, uint8_t pwmB,
                                     float kp, float ki, float kd,
                                     int pulses_per_rev, float dt, float iSat)
    : enca(enca), encb(encb), pwmF(pwmF), pwmB(pwmB),
      kp(kp), ki(ki), kd(kd), pulses_per_rev(pulses_per_rev),
      dt(dt), iSat(iSat)
{
    posi = 0;
    target_angle = 0;
    eprev = 0;
    eintegral = 0;
    lastEncoded = 0;
    lastCompute = 0;
}

// Đăng ký ngắt cho cả 2 chân encoder (A/B)
void MotorPID_Position::Init() {
    pinMode(enca, INPUT_PULLUP);
    pinMode(encb, INPUT_PULLUP);
    pinMode(pwmF, OUTPUT);
    pinMode(pwmB, OUTPUT);

    if (motorCount < MAX_PID_MOTORS) {
        motorList[motorCount++] = this;
        // Attach interrupt, mỗi chân 1 ISR static (không cần truyền pin vào ISR)
        attachInterrupt(digitalPinToInterrupt(enca), globalEncoderISR_A, CHANGE);
        attachInterrupt(digitalPinToInterrupt(encb), globalEncoderISR_B, CHANGE);
    }
}

// ISR toàn cục cho mọi chân A encoder
void MotorPID_Position::globalEncoderISR_A() {
    for (int i = 0; i < motorCount; ++i) {
        if (motorList[i] && digitalRead(motorList[i]->enca) != digitalRead(motorList[i]->lastEncoded >> 1)) {
            motorList[i]->handleEncoderInterrupt(motorList[i]->enca);
        }
    }
}
void MotorPID_Position::globalEncoderISR_B() {
    for (int i = 0; i < motorCount; ++i) {
        if (motorList[i] && digitalRead(motorList[i]->encb) != (motorList[i]->lastEncoded & 0x01)) {
            motorList[i]->handleEncoderInterrupt(motorList[i]->encb);
        }
    }
}

// Xử lý ngắt encoder
void MotorPID_Position::handleEncoderInterrupt(uint8_t encoderPin) {
    int MSB = digitalRead(enca);
    int LSB = digitalRead(encb);
    int encoded = (MSB << 1) | LSB;
    int sum = (lastEncoded << 2) | encoded;

    // Quadrature decoding: x4 mode
    if (sum == 0b1101 || sum == 0b0100 || sum == 0b0010 || sum == 0b1011) posi++;
    if (sum == 0b1110 || sum == 0b0111 || sum == 0b0001 || sum == 0b1000) posi--;
    lastEncoded = encoded;
}

// Đặt góc muốn giữ, tự động PID tính toán
void MotorPID_Position::Position(float angle) {
    target_angle = angle;
    unsigned long now = millis();
    if (now - lastCompute >= dt * 1000) {
        computePID();
        lastCompute = now;
    }
}

// Tính toán PID & xuất PWM
void MotorPID_Position::computePID() {
    long target_pulse = (long)(target_angle * pulses_per_rev / 360.0f);
    long curr_pulse = posi;
    long error = target_pulse - curr_pulse;

    float dedt = (error - eprev) / dt;
    eintegral += error * dt;
    eintegral = constrain(eintegral, -iSat, iSat);

    float u = kp * error + ki * eintegral + kd * dedt;
    eprev = error;

    int dir = (u > 0) ? 1 : -1;
    int pwr = constrain(abs((int)u), 0, 255);

    // Đủ gần target thì đứng lại
    if (abs(error) < 3) {
        setMotor(0, 0);
    } else {
        setMotor(dir, pwr);
    }
}

// Hàm điều khiển motor
void MotorPID_Position::setMotor(int dir, int pwm) {
    if (dir == 1) {
        analogWrite(pwmF, pwm);
        analogWrite(pwmB, 0);
    } else if (dir == -1) {
        analogWrite(pwmF, 0);
        analogWrite(pwmB, pwm);
    } else {
        analogWrite(pwmF, 0);
        analogWrite(pwmB, 0);
    }
}

// Reset encoder, dừng motor, reset biến PID
void MotorPID_Position::Home() {
    setMotor(0, 0);
    posi = 0;
    eprev = 0;
    eintegral = 0;
}

void MotorPID_Position::ResetPID() { eprev = 0; eintegral = 0; }
void MotorPID_Position::setPulsePerRev(int ppr) { pulses_per_rev = ppr; }
void MotorPID_Position::setPID(float kp_, float ki_, float kd_) { kp = kp_; ki = ki_; kd = kd_; }
void MotorPID_Position::setISat(float iSat_) { iSat = iSat_; }
float MotorPID_Position::getCurrentAngle() { return (float)posi * 360.0f / (float)pulses_per_rev; }
long MotorPID_Position::getCurrentPulse() { return posi; }
