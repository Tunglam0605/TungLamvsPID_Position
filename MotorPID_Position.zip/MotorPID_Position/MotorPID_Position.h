#ifndef MOTORPID_POSITION_H
#define MOTORPID_POSITION_H

#include <Arduino.h>

/*
 * MotorPID_Position.h - Multi-motor version (dynamic mapping)
 * Tác giả: Nguyễn Khắc Tùng Lâm
 * Facebook: Lâm Tùng | TikTok: @Tunglam0605 | SĐT: 0325270213
 *
 * Thư viện điều khiển vị trí động cơ DC sử dụng encoder & PID cho nhiều động cơ cùng lúc.
 * Tương thích Arduino Due, Mega, Uno... (ưu tiên Due/Mega vì nhiều interrupt hardware).
 *
 * Sử dụng:
 *   - Tạo object MotorPID_Position cho mỗi động cơ với các chân ENCA, ENCB, PWM thuận/nghịch, hệ số PID, pulses_per_rev.
 *   - Gọi .Init() trong setup() để đăng ký ngắt encoder, mapping động cơ tự động.
 *   - Trong loop, chỉ cần gọi .Position(góc) để giữ vị trí; muốn reset encoder gọi .Home();
 *   - Có thể đổi số xung/vòng, hệ số PID, giới hạn tích phân bất kỳ lúc nào.
 * 
 * Liên hệ - Kết nối:
 *   - Facebook: Lâm Tùng
 *   - TikTok: @Tunglam0605
 *   - SĐT: 0325270213
 */

#define MAX_PID_MOTORS 8   // Số động cơ tối đa quản lý cùng lúc

class MotorPID_Position {
public:
    // --- Khởi tạo đối tượng điều khiển động cơ ---
    MotorPID_Position(uint8_t enca, uint8_t encb, uint8_t pwmF, uint8_t pwmB,
                      float kp, float ki, float kd,
                      int pulses_per_rev,
                      float dt = 0.01,         // Thời gian lấy mẫu (s)
                      float iSat = 500.0f);    // Giới hạn tích phân

    void Init();                                // Đăng ký ngắt encoder, khai báo chân motor
    void Position(float angle);                 // Đặt góc muốn giữ vị trí (độ)
    void moveNRound(int n, bool autoCorrection = true); // Quay n vòng từ vị trí hiện tại, bù sai số xung
    void setEnable(bool en);                    // Bật/tắt PID (tắt = motor tự do, bật = giữ vị trí mới)
    void Home();                                // Reset encoder về 0, reset PID
    void Stop();                                // Dừng motor (PWM=0)
    void ResetPID();                            // Reset biến PID (không ảnh hưởng posi)

    void setPulsePerRev(int ppr);               // Đổi số xung/vòng
    void setPID(float kp, float ki, float kd);  // Đổi hệ số PID (giá trị tối ưu ghim vị trí)
    void setFastPIDOffset(float kp_off, float kd_off); // Đổi offset bộ PID mạnh khi sai số lớn
    void setISat(float iSat);                   // Đổi giới hạn tích phân

    float getCurrentAngle();                    // Đọc góc hiện tại (độ)
    long getCurrentPulse();                     // Đọc số xung encoder thực tế

    // --- ISR callback (static) cho toàn bộ hệ thống động cơ ---
    static void globalEncoderISR_A();
    static void globalEncoderISR_B();

private:
    uint8_t enca, encb, pwmF, pwmB;
    volatile long posi;                 // Số xung hiện tại
    int pulses_per_rev;                 // Tổng xung 1 vòng

    float kp, ki, kd;                   // PID giữ vị trí tối ưu
    float kp_fast, ki_fast, kd_fast;    // PID mạnh khi sai số lớn
    float kp_offset = 5, kd_offset = 0.5; // Offset auto scale PID nhanh
    float dt;                           // Thời gian lấy mẫu
    float iSat;                         // Giới hạn tích phân
    float eprev, eintegral;
    float target_angle;
    volatile int lastEncoded;           // Mã encoder trước đó (cho quadrature x4)
    unsigned long lastCompute;          // Lưu thời điểm tính PID cuối
    bool enabled = true;                // Trạng thái bật/tắt PID
    bool autoCorrection = true;         // Cho phép bù sai số xung

    // Static multi-motor list
    static MotorPID_Position* motorList[MAX_PID_MOTORS];
    static uint8_t motorCount;

    void handleEncoderInterrupt(uint8_t encoderPin);
    void computePID();
    void setMotor(int dir, int pwm);
    void autoCorrectIfNeeded(float lastTarget, float newTarget);
};

#endif
